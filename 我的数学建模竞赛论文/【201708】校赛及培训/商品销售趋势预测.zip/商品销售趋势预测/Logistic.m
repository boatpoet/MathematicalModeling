x=[1 2 3 4 5]'
y=[11 12 13 15 16]'
[fitresult, gof] = fit(t,y, 'b/(1+a*exp(-k*x))','Startpoint',[5000 5 1])