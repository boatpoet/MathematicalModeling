function f=Newton(x,y)
syms t;
if(length(x)==length(y))
    n=length(x);
    c(1:n)=0.0;
else
    disp('The dimensions of X and y are not equal!');
    return;
end
f=y(1);
y1=0;
l =1;
for(i=1:n-1)
    for(j=i+1:n)
        y1(j)=(y(j)-y(i))/(x(j)-x(i));
    end
    c(i)=y1(i+1);
    l=l*(t-x(i));
    f=f+c(i)*l;
    y=y1;
end
f=simplify(f);
A=zeros(n,n-1);
A=[y',A];
for j=2:n
    for i=j:n
    A(i,j)=(A(i,j-1)-A(i-1,j-1))/(x(i)-x(i+1-j));
    end
end
disp('The form of the difference quotient is:');
disp(A);
