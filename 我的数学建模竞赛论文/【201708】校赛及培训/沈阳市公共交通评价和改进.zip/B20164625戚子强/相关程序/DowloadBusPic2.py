import os  
import requests
os.makedirs('./image/', exist_ok=True)
order = 100
while order<=399:
    IMAGE_URL = "http://www.shenyangbus.com/pic/busline/v"+ str(order) + ".jpg"  
    response= requests.get(IMAGE_URL).status_code
    
    if response != 200:
        print(order)
        order = order +1
    
    else:    
        def urllib_download():  
            from urllib.request import urlretrieve  
            urlretrieve(IMAGE_URL, './image/v' + str(order) + '.jpg')

        urllib_download()  
        print('download img v ' + str(order))
        order = order + 1