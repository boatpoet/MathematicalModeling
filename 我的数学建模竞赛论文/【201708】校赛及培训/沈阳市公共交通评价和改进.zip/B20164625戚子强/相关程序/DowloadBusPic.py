import urllib2,os
from HTMLParser import HTMLParser  

class MyHTMLParser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        #self.links = {}

    def handle_starttag(self, tag, attrs):
        #print "Encountered the beginning of a %s tag" % tag
        if tag == "img":
            if len(attrs) == 0: pass
            else:
                for (variable, value)  in attrs:
                    if variable == "src" and value[0:4] == 'http' and value.find('x') >= 0:
                        pic_name = value.split('/')[-1]
                        print pic_name
                        down_image(value, pic_name)


def down_image(url,file_name):
    global headers
    req = urllib2.Request(url = url, headers = headers)
    binary_data = urllib2.urlopen(req).read()
    temp_file = open(file_name, 'wb')
    temp_file.write(binary_data)
    temp_file.close()



if __name__ == "__main__":
    img_dir = "D:\\Downloads\\domain images"

    if not os.path.isdir(img_dir):
        os.mkdir(img_dir)

    os.chdir(img_dir)
    print os.getcwd()
    url = ""
    headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0'}
    all_links = []
    hp = MyHTMLParser()

    for i in range(1,30):
        url = 'http://www.shenyangbus.com/pic/busline/' + str(i) + '/.jpg'
        req = urllib2.Request(url = url, headers = headers)
        content = urllib2.urlopen(req).read()
        hp.feed(content)

    hp.close()